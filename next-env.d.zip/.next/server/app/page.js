(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8293:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server");

/***/ }),

/***/ 5752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 7640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 6931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 7597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 5927:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client.edge");

/***/ }),

/***/ 1170:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 9491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 2361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 7147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 3685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 2037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 2781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 6224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 6783:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4421)), "C:\\Users\\John\\Documents\\GitHub\\personal-website\\app\\page.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3006)), "C:\\Users\\John\\Documents\\GitHub\\personal-website\\app\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\John\\Documents\\GitHub\\personal-website\\app\\page.tsx"];
    
    const originalPathname = "/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 5763:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'7064d2f3cf5c240c63af07bd224b7c7dc7076eb6': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 200)).then(mod => mod["sendEmail"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()
  return action.apply(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  '7064d2f3cf5c240c63af07bd224b7c7dc7076eb6': endpoint.bind(null, '7064d2f3cf5c240c63af07bd224b7c7dc7076eb6'),
}


/***/ }),

/***/ 3433:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2038));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6762));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3838));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7980));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4320));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2617));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3945))

/***/ }),

/***/ 1403:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2226));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 949));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9238));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 798));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3518))

/***/ }),

/***/ 809:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8782, 23))

/***/ }),

/***/ 2038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ About)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_heading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7038);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5996);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6229);
/* __next_internal_client_entry_do_not_use__ default auto */ 




function About() {
    const { ref } = (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_3__/* .useSectionInView */ .r)("About");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__/* .motion */ .E.section, {
        ref: ref,
        className: "mb-28 max-w-[45rem] text-center leading-8 sm:mb-40 scroll-mt-28",
        initial: {
            opacity: 0,
            y: 100
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            delay: 0.175
        },
        id: "about",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_section_heading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: "About me"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "mb-3",
                children: [
                    "I graduated with a degree in",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-medium",
                        children: "Computer Science and Engineering"
                    }),
                    ", I decided to pursue my passion for programming. I am a Highly skilled and motivated",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-medium",
                        children: "full-stack web development"
                    }),
                    ".",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "italic",
                        children: "My favorite part of programming"
                    }),
                    " is the problem-solving aspect. I ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "underline",
                        children: "love"
                    }),
                    " the feeling of finally figuring out a solution to a problem. My core stack is",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-medium",
                        children: "React, Next.js, Node.js, and MongoDB"
                    }),
                    ". I am also familiar with TypeScript and Docker. I am always looking to learn new technologies. I am currently looking for a",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-medium",
                        children: "full-time position"
                    }),
                    " as a software developer."
                ]
            })
        ]
    });
}


/***/ }),

/***/ 6762:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Contact)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(7640);
// EXTERNAL MODULE: ./components/section-heading.tsx
var section_heading = __webpack_require__(7038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 169 modules
var motion = __webpack_require__(5996);
// EXTERNAL MODULE: ./lib/hooks.ts
var hooks = __webpack_require__(6229);
// EXTERNAL MODULE: ./node_modules/next/dist/client/app-call-server.js
var app_call_server = __webpack_require__(4783);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-proxy.js
var action_proxy = __webpack_require__(9025);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js
var action_client_wrapper = __webpack_require__(3787);
;// CONCATENATED MODULE: ./actions/sendEmail.ts



function __build_action__(action, args) {
  return callServer(action.$$id, args)
}

/* __next_internal_action_entry_do_not_use__ sendEmail */ 

var sendEmail = (0,action_client_wrapper/* default */.Z)("7064d2f3cf5c240c63af07bd224b7c7dc7076eb6");


// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(6775);
// EXTERNAL MODULE: external "next/dist/compiled/react-dom-experimental/server-rendering-stub"
var server_rendering_stub_ = __webpack_require__(5752);
;// CONCATENATED MODULE: ./components/submit-btn.tsx




function SubmitBtn() {
    const { pending } = (0,server_rendering_stub_.experimental_useFormStatus)();
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        type: "submit",
        className: "group flex items-center justify-center gap-2 h-[3rem] w-[8rem] bg-gray-900 text-white rounded-full outline-none transition-all focus:scale-110 hover:scale-110 hover:bg-gray-950 active:scale-105 dark:bg-white dark:bg-opacity-10 disabled:scale-100 disabled:bg-opacity-65",
        disabled: pending,
        children: pending ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "h-5 w-5 animate-spin rounded-full border-b-2 border-white"
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                "Submit",
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaPaperPlane */.Y2X, {
                    className: "text-xs opacity-70 transition-all group-hover:translate-x-1 group-hover:-translate-y-1"
                }),
                " "
            ]
        })
    });
}

// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(3518);
;// CONCATENATED MODULE: ./components/contact.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







function Contact() {
    const { ref } = (0,hooks/* useSectionInView */.r)("Contact");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.section, {
        id: "contact",
        ref: ref,
        className: "mb-20 sm:mb-28 w-[min(100%,38rem)] text-center",
        initial: {
            opacity: 0
        },
        whileInView: {
            opacity: 1
        },
        transition: {
            duration: 1
        },
        viewport: {
            once: true
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_heading/* default */.Z, {
                children: "Contact me"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-gray-700 -mt-6 dark:text-white/80",
                children: [
                    "Please contact me directly at",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "underline",
                        href: "yohannesgirma543@gmail.com",
                        children: "yohannesgirma543@gmail.com"
                    }),
                    " ",
                    "or through this form."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                className: "mt-10 flex flex-col dark:text-black",
                action: async (formData)=>{
                    const { data, error } = await sendEmail(formData);
                    if (error) {
                        dist["default"].error(error);
                        return;
                    }
                    dist["default"].success("Email sent successfully!");
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        className: "h-14 px-4 rounded-lg borderBlack dark:bg-white dark:bg-opacity-80 dark:focus:bg-opacity-100 transition-all dark:outline-none",
                        name: "senderEmail",
                        type: "email",
                        required: true,
                        maxLength: 500,
                        placeholder: "Your email"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                        className: "h-52 my-3 rounded-lg borderBlack p-4 dark:bg-white dark:bg-opacity-80 dark:focus:bg-opacity-100 transition-all dark:outline-none",
                        name: "message",
                        placeholder: "Your message",
                        required: true,
                        maxLength: 5000
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SubmitBtn, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Experience)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_heading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7038);
/* harmony import */ var react_vertical_timeline_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7142);
/* harmony import */ var react_vertical_timeline_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_vertical_timeline_component__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_vertical_timeline_component_style_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5119);
/* harmony import */ var react_vertical_timeline_component_style_min_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_vertical_timeline_component_style_min_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1941);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6229);
/* harmony import */ var _context_theme_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(798);
/* __next_internal_client_entry_do_not_use__ default auto */ 







function Experience() {
    const { ref } = (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_6__/* .useSectionInView */ .r)("Experience");
    const { theme } = (0,_context_theme_context__WEBPACK_IMPORTED_MODULE_7__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "experience",
        ref: ref,
        className: "scroll-mt-28 mb-28 sm:mb-40",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_section_heading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: "My experience"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_vertical_timeline_component__WEBPACK_IMPORTED_MODULE_3__.VerticalTimeline, {
                lineColor: "",
                children: _lib_data__WEBPACK_IMPORTED_MODULE_5__/* .experiencesData */ .$c.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_vertical_timeline_component__WEBPACK_IMPORTED_MODULE_3__.VerticalTimelineElement, {
                            contentStyle: {
                                background: theme === "light" ? "#f3f4f6" : "rgba(255, 255, 255, 0.05)",
                                boxShadow: "none",
                                border: "1px solid rgba(0, 0, 0, 0.05)",
                                textAlign: "left",
                                padding: "1.3rem 2rem"
                            },
                            contentArrowStyle: {
                                borderRight: theme === "light" ? "0.4rem solid #9ca3af" : "0.4rem solid rgba(255, 255, 255, 0.5)"
                            },
                            date: item.date,
                            icon: item.icon,
                            iconStyle: {
                                background: theme === "light" ? "white" : "rgba(255, 255, 255, 0.15)",
                                fontSize: "1.5rem"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "font-semibold capitalize",
                                    children: item.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "font-normal !mt-0",
                                    children: item.location
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "!mt-1 !font-normal text-gray-700 dark:text-white/75",
                                    children: item.description
                                })
                            ]
                        })
                    }, index))
            })
        ]
    });
}


/***/ }),

/***/ 2226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5996);
/* harmony import */ var _lib_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1941);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4889);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_active_section_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9238);
/* __next_internal_client_entry_do_not_use__ default auto */ 






function Header() {
    const { activeSection, setActiveSection, setTimeOfLastClick } = (0,_context_active_section_context__WEBPACK_IMPORTED_MODULE_5__.useActiveSectionContext)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: "z-[999] relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .motion */ .E.div, {
                className: "fixed top-0 left-1/2 h-[4.5rem] w-full rounded-none border border-white border-opacity-40 bg-white bg-opacity-80 shadow-lg shadow-black/[0.03] backdrop-blur-[0.5rem] sm:top-6 sm:h-[3.25rem] sm:w-[36rem] sm:rounded-full dark:bg-gray-950 dark:border-black/40 dark:bg-opacity-75",
                initial: {
                    y: -100,
                    x: "-50%",
                    opacity: 0
                },
                animate: {
                    y: 0,
                    x: "-50%",
                    opacity: 1
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: "flex fixed top-[0.15rem] left-1/2 h-12 -translate-x-1/2 py-2 sm:top-[1.7rem] sm:h-[initial] sm:py-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "flex w-[22rem] flex-wrap items-center justify-center gap-y-1 text-[0.9rem] font-medium text-gray-500 sm:w-[initial] sm:flex-nowrap sm:gap-5",
                    children: _lib_data__WEBPACK_IMPORTED_MODULE_2__/* .links */ .Ok.map((link)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .motion */ .E.li, {
                            className: "h-3/4 flex items-center justify-center relative",
                            initial: {
                                y: -100,
                                opacity: 0
                            },
                            animate: {
                                y: 0,
                                opacity: 1
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                className: clsx__WEBPACK_IMPORTED_MODULE_4___default()("flex w-full items-center justify-center px-3 py-3 hover:text-gray-950 transition dark:text-gray-500 dark:hover:text-gray-300", {
                                    "text-gray-950 dark:text-gray-200": activeSection === link.name
                                }),
                                href: link.hash,
                                onClick: ()=>{
                                    setActiveSection(link.name);
                                    setTimeOfLastClick(Date.now());
                                },
                                children: [
                                    link.name,
                                    link.name === activeSection && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__/* .motion */ .E.span, {
                                        className: "bg-gray-100 rounded-full absolute inset-0 -z-10 dark:bg-gray-800",
                                        layoutId: "activeSection",
                                        transition: {
                                            type: "spring",
                                            stiffness: 380,
                                            damping: 30
                                        }
                                    })
                                ]
                            })
                        }, link.hash))
                })
            })
        ]
    });
}


/***/ }),

/***/ 7980:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Intro)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(7640);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 169 modules
var motion = __webpack_require__(5996);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/react-icons/bs/index.esm.js
var index_esm = __webpack_require__(5484);
// EXTERNAL MODULE: ./node_modules/react-icons/hi/index.esm.js
var hi_index_esm = __webpack_require__(5655);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(6775);
// EXTERNAL MODULE: ./lib/hooks.ts
var hooks = __webpack_require__(6229);
// EXTERNAL MODULE: ./context/active-section-context.tsx
var active_section_context = __webpack_require__(9238);
;// CONCATENATED MODULE: ./public/DSC_0182.png
/* harmony default export */ const DSC_0182 = ({"src":"/_next/static/media/DSC_0182.39f30eed.png","height":600,"width":480,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAAo0lEQVR42gGYAGf/AMfS7cfT7ZWlvJ+uxMnV78bS7ADL2PKtt86hcWWQZl2xv9bL1/EAytjzsrTI1ZyMvol7rrfMzNjzAMfU78TL4MKPh7OIhL/J4cjU7gDI1e/M2vOUfIF9bHfH1vDK1/EAwMnipaa4kXd5g2ttmZmot77UAI6Ejox/h46Ejo2EjYt/hod6ggCIfoeSiJKMgYqKgImPhY+CeYPHt2EGeX+UjwAAAABJRU5ErkJggg==","blurWidth":6,"blurHeight":8});
;// CONCATENATED MODULE: ./components/intro.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










function Intro() {
    const { ref } = (0,hooks/* useSectionInView */.r)("Home", 0.5);
    const { setActiveSection, setTimeOfLastClick } = (0,active_section_context.useActiveSectionContext)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        ref: ref,
        id: "home",
        className: "mb-28 max-w-[50rem] text-center sm:mb-0 scroll-mt-[100rem]",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                            initial: {
                                opacity: 0,
                                scale: 0
                            },
                            animate: {
                                opacity: 1,
                                scale: 1
                            },
                            transition: {
                                type: "tween",
                                duration: 0.2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: DSC_0182,
                                alt: "Yohannes portrait",
                                width: "192",
                                height: "192",
                                quality: "95",
                                priority: true,
                                className: "h-24 w-24 rounded-full object-cover border-[0.35rem] border-white shadow-xl"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.span, {
                            className: "absolute bottom-0 right-0 text-4xl",
                            initial: {
                                opacity: 0,
                                scale: 0
                            },
                            animate: {
                                opacity: 1,
                                scale: 1
                            },
                            transition: {
                                type: "spring",
                                stiffness: 125,
                                delay: 0.1,
                                duration: 0.7
                            },
                            children: "\uD83D\uDC4B"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.h1, {
                className: "mb-10 mt-4 px-4 text-2xl font-medium !leading-[1.5] sm:text-4xl",
                initial: {
                    opacity: 0,
                    y: 100
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: "Hello, I'm Yohannes Girma."
                    }),
                    " I'm a",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold",
                        children: "full-stack developer."
                    }),
                    " ",
                    "  I enjoy building ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "italic",
                        children: "sites & apps"
                    }),
                    ". My focus is",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "underline",
                        children: "React (Next.js)"
                    }),
                    "."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion */.E.div, {
                className: "flex flex-col sm:flex-row items-center justify-center gap-2 px-4 text-lg font-medium",
                initial: {
                    opacity: 0,
                    y: 100
                },
                animate: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    delay: 0.1
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: "#contact",
                        className: "group bg-gray-900 text-white px-7 py-3 flex items-center gap-2 rounded-full outline-none focus:scale-110 hover:scale-110 hover:bg-gray-950 active:scale-105 transition",
                        onClick: ()=>{
                            setActiveSection("Contact");
                            setTimeOfLastClick(Date.now());
                        },
                        children: [
                            "Contact me here",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsArrowRight */.lzl, {
                                className: "opacity-70 group-hover:translate-x-1 transition"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                        className: "group bg-white px-7 py-3 flex items-center gap-2 rounded-full outline-none focus:scale-110 hover:scale-110 active:scale-105 transition cursor-pointer borderBlack dark:bg-white/10",
                        href: "/CV.pdf",
                        download: true,
                        children: [
                            "Download CV",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(hi_index_esm/* HiDownload */.H_7, {
                                className: "opacity-60 group-hover:translate-y-1 transition"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "bg-white p-4 text-gray-700 hover:text-gray-950 flex items-center gap-2 rounded-full focus:scale-[1.15] hover:scale-[1.15] active:scale-105 transition cursor-pointer borderBlack dark:bg-white/10 dark:text-white/60",
                        href: "https://www.linkedin.com/in/yohannesgirma",
                        target: "_blank",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BsLinkedin */.NQh, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "bg-white p-4 text-gray-700 flex items-center gap-2 text-[1.35rem] rounded-full focus:scale-[1.15] hover:scale-[1.15] hover:text-gray-950 active:scale-105 transition cursor-pointer borderBlack dark:bg-white/10 dark:text-white/60",
                        href: "https://github.com/JohnGirma",
                        target: "_blank",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_index_esm/* FaGithubSquare */.NML, {})
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Projects)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(7640);
var react_experimental_default = /*#__PURE__*/__webpack_require__.n(react_experimental_);
// EXTERNAL MODULE: ./components/section-heading.tsx
var section_heading = __webpack_require__(7038);
// EXTERNAL MODULE: ./lib/data.ts + 3 modules
var data = __webpack_require__(1941);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-scroll.mjs + 12 modules
var use_scroll = __webpack_require__(8239);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-transform.mjs + 3 modules
var use_transform = __webpack_require__(4250);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 169 modules
var motion = __webpack_require__(5996);
;// CONCATENATED MODULE: ./components/project.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Project({ title, description, tags, imageUrl }) {
    const ref = (0,react_experimental_.useRef)(null);
    const { scrollYProgress } = (0,use_scroll/* useScroll */.v)({
        target: ref,
        offset: [
            "0 1",
            "1.33 1"
        ]
    });
    const scaleProgess = (0,use_transform/* useTransform */.H)(scrollYProgress, [
        0,
        1
    ], [
        0.8,
        1
    ]);
    const opacityProgess = (0,use_transform/* useTransform */.H)(scrollYProgress, [
        0,
        1
    ], [
        0.6,
        1
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
        ref: ref,
        style: {
            scale: scaleProgess,
            opacity: opacityProgess
        },
        className: "group mb-3 sm:mb-8 last:mb-0",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "bg-gray-100 max-w-[42rem] border border-black/5 rounded-lg overflow-hidden sm:pr-8 relative sm:h-[20rem] hover:bg-gray-200 transition sm:group-even:pl-8 dark:text-white dark:bg-white/10 dark:hover:bg-white/20",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "pt-4 pb-7 px-5 sm:pl-10 sm:pr-2 sm:pt-10 sm:max-w-[50%] flex flex-col h-full sm:group-even:ml-[18rem]",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "text-2xl font-semibold",
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "mt-2 leading-relaxed text-gray-700 dark:text-white/70",
                            children: description
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "flex flex-wrap mt-4 gap-2 sm:mt-auto",
                            children: tags.map((tag, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "bg-black/[0.7] px-3 py-1 text-[0.7rem] uppercase tracking-wider text-white rounded-full dark:text-white/70",
                                    children: tag
                                }, index))
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: imageUrl,
                    alt: "Project I worked on",
                    quality: 95,
                    className: "absolute hidden sm:block top-8 -right-40 w-[28.25rem] rounded-t-lg shadow-2xl   transition    group-hover:scale-[1.04]   group-hover:-translate-x-3   group-hover:translate-y-3   group-hover:-rotate-2      group-even:group-hover:translate-x-3   group-even:group-hover:translate-y-3   group-even:group-hover:rotate-2      group-even:right-[initial] group-even:-left-40"
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./lib/hooks.ts
var hooks = __webpack_require__(6229);
;// CONCATENATED MODULE: ./components/projects.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





function Projects() {
    const { ref } = (0,hooks/* useSectionInView */.r)("Projects", 0.5);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        ref: ref,
        id: "projects",
        className: "scroll-mt-28 mb-28",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(section_heading/* default */.Z, {
                children: "My projects"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: data/* projectsData */.nD.map((project, index)=>/*#__PURE__*/ jsx_runtime_.jsx((react_experimental_default()).Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Project, {
                            ...project
                        })
                    }, index))
            })
        ]
    });
}


/***/ }),

/***/ 2617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SectionDivider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5996);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function SectionDivider() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion */ .E.div, {
        className: "bg-gray-200 my-24 h-16 w-1 rounded-full hidden sm:block dark:bg-opacity-20",
        initial: {
            opacity: 0,
            y: 100
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            delay: 0.125
        }
    });
}


/***/ }),

/***/ 7038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ SectionHeading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function SectionHeading({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
        className: "text-3xl font-medium capitalize mb-8 text-center",
        children: children
    });
}


/***/ }),

/***/ 3945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Skills)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _section_heading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7038);
/* harmony import */ var _lib_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1941);
/* harmony import */ var _lib_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6229);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5996);
/* __next_internal_client_entry_do_not_use__ default auto */ 





const fadeInAnimationVariants = {
    initial: {
        opacity: 0,
        y: 100
    },
    animate: (index)=>({
            opacity: 1,
            y: 0,
            transition: {
                delay: 0.05 * index
            }
        })
};
function Skills() {
    const { ref } = (0,_lib_hooks__WEBPACK_IMPORTED_MODULE_4__/* .useSectionInView */ .r)("Skills");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: "skills",
        ref: ref,
        className: "mb-28 max-w-[53rem] scroll-mt-28 text-center sm:mb-40",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_section_heading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: "My skills"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "flex flex-wrap justify-center gap-2 text-lg text-gray-800",
                children: _lib_data__WEBPACK_IMPORTED_MODULE_3__/* .skillsData */ .ZU.map((skill, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__/* .motion */ .E.li, {
                        className: "bg-white borderBlack rounded-xl px-5 py-3 dark:bg-white/10 dark:text-white/80",
                        variants: fadeInAnimationVariants,
                        initial: "initial",
                        whileInView: "animate",
                        viewport: {
                            once: true
                        },
                        custom: index,
                        children: skill
                    }, index))
            })
        ]
    });
}


/***/ }),

/***/ 949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ThemeSwitch)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_theme_context__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(798);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5484);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function ThemeSwitch() {
    const { theme, toggleTheme } = (0,_context_theme_context__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "fixed bottom-5 right-5 bg-white w-[3rem] h-[3rem] bg-opacity-80 backdrop-blur-[0.5rem] border border-white border-opacity-40 shadow-2xl rounded-full flex items-center justify-center hover:scale-[1.15] active:scale-105 transition-all dark:bg-gray-950",
        onClick: toggleTheme,
        children: theme === "light" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__/* .BsSun */ .eSY, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__/* .BsMoon */ .s1t, {})
    });
}


/***/ }),

/***/ 9238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ActiveSectionContext: () => (/* binding */ ActiveSectionContext),
/* harmony export */   "default": () => (/* binding */ ActiveSectionContextProvider),
/* harmony export */   useActiveSectionContext: () => (/* binding */ useActiveSectionContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ ActiveSectionContext,default,useActiveSectionContext auto */ 

const ActiveSectionContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function ActiveSectionContextProvider({ children }) {
    const [activeSection, setActiveSection] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Home");
    const [timeOfLastClick, setTimeOfLastClick] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0); // we need to keep track of this to disable the observer temporarily when user clicks on a link
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ActiveSectionContext.Provider, {
        value: {
            activeSection,
            setActiveSection,
            timeOfLastClick,
            setTimeOfLastClick
        },
        children: children
    });
}
function useActiveSectionContext() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ActiveSectionContext);
    if (context === null) {
        throw new Error("useActiveSectionContext must be used within an ActiveSectionContextProvider");
    }
    return context;
}


/***/ }),

/***/ 798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ThemeContextProvider),
/* harmony export */   useTheme: () => (/* binding */ useTheme)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default,useTheme auto */ 

const ThemeContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
function ThemeContextProvider({ children }) {
    const [theme, setTheme] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("light");
    const toggleTheme = ()=>{
        if (theme === "light") {
            setTheme("dark");
            window.localStorage.setItem("theme", "dark");
            document.documentElement.classList.add("dark");
        } else {
            setTheme("light");
            window.localStorage.setItem("theme", "light");
            document.documentElement.classList.remove("dark");
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const localTheme = window.localStorage.getItem("theme");
        if (localTheme) {
            setTheme(localTheme);
            if (localTheme === "dark") {
                document.documentElement.classList.add("dark");
            }
        } else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
            setTheme("dark");
            document.documentElement.classList.add("dark");
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ThemeContext.Provider, {
        value: {
            theme,
            toggleTheme
        },
        children: children
    });
}
function useTheme() {
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ThemeContext);
    if (context === null) {
        throw new Error("useTheme must be used within a ThemeContextProvider");
    }
    return context;
}


/***/ }),

/***/ 1941:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  $c: () => (/* binding */ experiencesData),
  Ok: () => (/* binding */ links),
  nD: () => (/* binding */ projectsData),
  ZU: () => (/* binding */ skillsData)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(7640);
var react_experimental_default = /*#__PURE__*/__webpack_require__.n(react_experimental_);
// EXTERNAL MODULE: ./node_modules/react-icons/cg/index.esm.js
var index_esm = __webpack_require__(2314);
// EXTERNAL MODULE: ./node_modules/react-icons/fa/index.esm.js
var fa_index_esm = __webpack_require__(6775);
// EXTERNAL MODULE: ./node_modules/react-icons/lu/index.esm.js
var lu_index_esm = __webpack_require__(3759);
;// CONCATENATED MODULE: ./public/corpcomment.png
/* harmony default export */ const corpcomment = ({"src":"/_next/static/media/corpcomment.c443fc25.png","height":901,"width":1917,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAXklEQVR42iWMwQqAIBBE/f+P6lx4jsCgIjQRc3V31Tq2EMxhmDczqlCDwhmrCLCGK6Q7S6KQu/NxXtZU+NwPPQzUXsikqD7WemM2aVjnp1GzAFkU7ilCBhQjTNL/9gM3d1hQ1OXAUgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./public/rmtdev.png
/* harmony default export */ const rmtdev = ({"src":"/_next/static/media/rmtdev.a1084034.png","height":902,"width":1143,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAfElEQVR42h3MsQ3CMBQE0PvfDgliEoSYgR0YlQUoKEnBGlRBWCJB8f8X2684XXE6weV1Our13AcF6Cp+G6fxnuTxfB8GDINAlKQqvuk/fWYhDajj9FtQECGqu8d5yft+l81zdmu6rjNjDCqoN1KEphTSonm1rrkkGhLu3ABgHUX18YSEZwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/wordanalytics.png
/* harmony default export */ const wordanalytics = ({"src":"/_next/static/media/wordanalytics.dd5fae24.png","height":765,"width":1354,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAgElEQVR42g3MsQ3CMBAF0Dv7rEDAoaJhD4TENgyQhl2YgJJFQGIMKAEFRZEV5+7H7Ssev24toMQU960PobtfoInZC8iYiiP338zCpACITVy92xxO4jj9PxJCdTxXq/h7XMVLGH1jrNTUk3PO8mDLMommDu/nBLVcasZ66xfRxn4GkiI1mSocPAMAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./lib/data.ts







const links = [
    {
        name: "Home",
        hash: "#home"
    },
    {
        name: "About",
        hash: "#about"
    },
    {
        name: "Projects",
        hash: "#projects"
    },
    {
        name: "Skills",
        hash: "#skills"
    },
    {
        name: "Experience",
        hash: "#experience"
    },
    {
        name: "Contact",
        hash: "#contact"
    }
];
const experiencesData = [
    {
        title: "Bachelor Degree  ",
        location: "Adama Science and Technology University Adama, Ethiopia",
        description: "Computer Science and Engineering",
        icon: react_experimental_default().createElement(lu_index_esm/* LuGraduationCap */.qWM),
        date: "2023"
    },
    {
        title: "Front-End Developer",
        location: "Addis Ababa, ETHIOPIA",
        description: "I worked as a front-end developer for 2 years in 1 job and 1 year in another job. I also upskilled to the full stack.",
        icon: react_experimental_default().createElement(index_esm/* CgWorkAlt */.zQU),
        date: "2019 - 2021"
    },
    {
        title: "Full-Stack Developer",
        location: "Addis Ababa, ETHIOPIA",
        description: "I'm now a full-stack developer working as a freelancer. My stack includes React, Next.js, TypeScript, Tailwind, Prisma and MongoDB. I'm open to full-time opportunities.",
        icon: react_experimental_default().createElement(fa_index_esm/* FaReact */.huN),
        date: "2021 - 2020"
    }
];
const projectsData = [
    {
        title: "Smart exam monitoring system",
        description: "It is to effectively evaluate the examinees thoroughly through a totally automated system and obtain fast and accurate results.",
        tags: [
            "React",
            "Redux Toolkit",
            "Matrial ui",
            "RestAPI"
        ],
        imageUrl: corpcomment
    },
    {
        title: "Web Testing | Intern | condigital.io",
        description: "Test all aspects of the web application's functionality, including looking for bugs with usability, compatibility, security, and general performance.",
        tags: [
            "Selenium Grid  ",
            "Selenium IDE"
        ],
        imageUrl: rmtdev
    },
    {
        title: "MiniMicroservicesBlog",
        description: "A mini microservice blog project using 4 node js service nextjs app.",
        tags: [
            "React",
            "Next.js",
            "mongodb",
            "Tailwind"
        ],
        imageUrl: wordanalytics
    }
];
const skillsData = [
    "HTML",
    "CSS",
    "JavaScript",
    "TypeScript",
    "React",
    "Next.js",
    "Node.js",
    "Git",
    "Tailwind",
    "MongoDB",
    "Redux",
    "GraphQL",
    "Apollo",
    "Express",
    "PostgreSQL",
    "Python",
    "Docker",
    "Framer Motion"
];


/***/ }),

/***/ 6229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   r: () => (/* binding */ useSectionInView)
/* harmony export */ });
/* harmony import */ var _context_active_section_context__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9238);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1257);



function useSectionInView(sectionName, threshold = 0.75) {
    const { ref, inView } = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_2__/* .useInView */ .YD)({
        threshold
    });
    const { setActiveSection, timeOfLastClick } = (0,_context_active_section_context__WEBPACK_IMPORTED_MODULE_0__.useActiveSectionContext)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (inView && Date.now() - timeOfLastClick > 1000) {
            setActiveSection(sectionName);
        }
    }, [
        inView,
        setActiveSection,
        timeOfLastClick,
        sectionName
    ]);
    return {
        ref
    };
}


/***/ }),

/***/ 200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sendEmail: () => (/* binding */ sendEmail)
/* harmony export */ });
/* harmony import */ var private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6315);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var resend__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2058);
/* harmony import */ var _lib_utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6836);
/* harmony import */ var _email_contact_form_email__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9169);
/* harmony import */ var private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9730);
/* __next_internal_action_entry_do_not_use__ sendEmail */ 




const resend = new resend__WEBPACK_IMPORTED_MODULE_2__.Resend(process.env.RESEND_API_KEY);
const sendEmail = async (formData)=>{
    const senderEmail = formData.get("senderEmail");
    const message = formData.get("message");
    // simple server-side validation
    if (!(0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.validateString)(senderEmail, 500)) {
        return {
            error: "Invalid sender email"
        };
    }
    if (!(0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.validateString)(message, 5000)) {
        return {
            error: "Invalid message"
        };
    }
    let data;
    try {
        data = await resend.emails.send({
            from: "Contact Form <onboarding@resend.dev>",
            to: "bytegrad@gmail.com",
            subject: "Message from contact form",
            reply_to: senderEmail,
            react: react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_email_contact_form_email__WEBPACK_IMPORTED_MODULE_3__["default"], {
                message: message,
                senderEmail: senderEmail
            })
        });
    } catch (error) {
        return {
            error: (0,_lib_utils__WEBPACK_IMPORTED_MODULE_4__.getErrorMessage)(error)
        };
    }
    return {
        data
    };
};

(0,private_next_rsc_action_validate__WEBPACK_IMPORTED_MODULE_5__["default"])([
    sendEmail
]);
(0,private_next_rsc_action_proxy__WEBPACK_IMPORTED_MODULE_0__["default"])("7064d2f3cf5c240c63af07bd224b7c7dc7076eb6", null, sendEmail);


/***/ }),

/***/ 3006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(160);
var target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./components/header.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\header.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const header = (__default__);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(2817);
;// CONCATENATED MODULE: ./context/active-section-context.tsx

const active_section_context_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\context\active-section-context.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: active_section_context_esModule, $$typeof: active_section_context_$$typeof } = active_section_context_proxy;
const active_section_context_default_ = active_section_context_proxy.default;

const e0 = active_section_context_proxy["ActiveSectionContext"];


/* harmony default export */ const active_section_context = (active_section_context_default_);
const e1 = active_section_context_proxy["useActiveSectionContext"];

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(5465);
;// CONCATENATED MODULE: ./components/footer.tsx


function Footer() {
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "mb-10 px-4 text-center text-gray-500",
        children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
            className: "mb-2 block text-xs",
            children: "\xa9 2023 Yohannes Girma. All rights reserved."
        })
    });
}

;// CONCATENATED MODULE: ./components/theme-switch.tsx

const theme_switch_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\theme-switch.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: theme_switch_esModule, $$typeof: theme_switch_$$typeof } = theme_switch_proxy;
const theme_switch_default_ = theme_switch_proxy.default;


/* harmony default export */ const theme_switch = (theme_switch_default_);
;// CONCATENATED MODULE: ./context/theme-context.tsx

const theme_context_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\context\theme-context.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: theme_context_esModule, $$typeof: theme_context_$$typeof } = theme_context_proxy;
const theme_context_default_ = theme_context_proxy.default;


/* harmony default export */ const theme_context = (theme_context_default_);
const theme_context_e0 = theme_context_proxy["useTheme"];

// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(9035);
;// CONCATENATED MODULE: ./app/layout.tsx









const metadata = {
    title: "Yohannes  | Personal Portfolio",
    description: "Yohannes is a full-stack developer."
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        className: "!scroll-smooth",
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: `${(target_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className} bg-gray-50 text-gray-950 relative pt-28 sm:pt-36 dark:bg-gray-900 dark:text-gray-50 dark:text-opacity-90`,
            children: /*#__PURE__*/ jsx_runtime_.jsx(theme_context, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(active_section_context, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(header, {}),
                        children,
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(dist/* Toaster */.x7, {
                            position: "top-right"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(theme_switch, {})
                    ]
                })
            })
        })
    });
}


/***/ }),

/***/ 4421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6931);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./components/about.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\about.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const about = (__default__);
;// CONCATENATED MODULE: ./components/contact.tsx

const contact_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\contact.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: contact_esModule, $$typeof: contact_$$typeof } = contact_proxy;
const contact_default_ = contact_proxy.default;


/* harmony default export */ const contact = (contact_default_);
;// CONCATENATED MODULE: ./components/experience.tsx

const experience_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\experience.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: experience_esModule, $$typeof: experience_$$typeof } = experience_proxy;
const experience_default_ = experience_proxy.default;


/* harmony default export */ const experience = (experience_default_);
;// CONCATENATED MODULE: ./components/intro.tsx

const intro_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\intro.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: intro_esModule, $$typeof: intro_$$typeof } = intro_proxy;
const intro_default_ = intro_proxy.default;


/* harmony default export */ const intro = (intro_default_);
;// CONCATENATED MODULE: ./components/projects.tsx

const projects_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\projects.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: projects_esModule, $$typeof: projects_$$typeof } = projects_proxy;
const projects_default_ = projects_proxy.default;


/* harmony default export */ const projects = (projects_default_);
;// CONCATENATED MODULE: ./components/section-divider.tsx

const section_divider_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\section-divider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: section_divider_esModule, $$typeof: section_divider_$$typeof } = section_divider_proxy;
const section_divider_default_ = section_divider_proxy.default;


/* harmony default export */ const section_divider = (section_divider_default_);
;// CONCATENATED MODULE: ./components/skills.tsx

const skills_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\John\Documents\GitHub\personal-website\components\skills.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: skills_esModule, $$typeof: skills_$$typeof } = skills_proxy;
const skills_default_ = skills_proxy.default;


/* harmony default export */ const skills = (skills_default_);
;// CONCATENATED MODULE: ./app/page.tsx








function Home() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: "flex flex-col items-center px-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(intro, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(section_divider, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(about, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(projects, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(skills, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(experience, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(contact, {})
        ]
    });
}


/***/ }),

/***/ 9169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ContactFormEmail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_email_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7303);
/* harmony import */ var _react_email_tailwind__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1379);
/* harmony import */ var _react_email_tailwind__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_email_tailwind__WEBPACK_IMPORTED_MODULE_3__);




function ContactFormEmail({ message, senderEmail }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Html, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Head, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Preview, {
                children: "New message from your portfolio site"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_tailwind__WEBPACK_IMPORTED_MODULE_3__.Tailwind, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Body, {
                    className: "bg-gray-100 text-black",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Container, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Section, {
                            className: "bg-white borderBlack my-10 px-10 py-4 rounded-md",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Heading, {
                                    className: "leading-tight",
                                    children: "You received the following message from the contact form"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    children: message
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Hr, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_react_email_components__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    children: [
                                        "The sender's email is: ",
                                        senderEmail
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 6836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getErrorMessage: () => (/* binding */ getErrorMessage),
/* harmony export */   validateString: () => (/* binding */ validateString)
/* harmony export */ });
const validateString = (value, maxLength)=>{
    if (!value || typeof value !== "string" || value.length > maxLength) {
        return false;
    }
    return true;
};
const getErrorMessage = (error)=>{
    let message;
    if (error instanceof Error) {
        message = error.message;
    } else if (error && typeof error === "object" && "message" in error) {
        message = String(error.message);
    } else if (typeof error === "string") {
        message = error;
    } else {
        message = "Something went wrong";
    }
    return message;
};


/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,169], () => (__webpack_exec__(6783)));
module.exports = __webpack_exports__;

})();