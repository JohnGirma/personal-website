"use strict";
(() => {
var exports = {};
exports.id = 155;
exports.ids = [155];
exports.modules = {

/***/ 4021:
/***/ ((module) => {

module.exports = import("next/dist/compiled/@vercel/og/index.node.js");;

/***/ }),

/***/ 2037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 7856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__
var favicon_next_metadata_namespaceObject = {};
__webpack_require__.r(favicon_next_metadata_namespaceObject);
__webpack_require__.d(favicon_next_metadata_namespaceObject, {
  GET: () => (GET),
  dynamic: () => (dynamic)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(5387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(9267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/server.js
var server = __webpack_require__(4664);
;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./app/favicon.ico?__next_metadata__


const contentType = "image/x-icon"
const buffer = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAALESURBVHgBvZc7bxNBEMf/s3YSu4tTUl2cNJAg4jwqEDIS0AFpQDQIaBBU0CFEkSAhIbrwDfwRIFQkSDhCqXg4HUIiziERU9rdOUG+ZWb9iJ/ynl+/wr7du93/7Mw+ZgmWZDIHk4ioGyUfSUAvgOBw9WTldQEaLkB7UEiHiv67RGK6YNMvdfuAhR1/Qj3W0PfqBLujKaVobH3xzKnf6MUAGTELr7HwE/QBgTbUkf+ik0eogziPmj5pGDcPAldhPNnOG6q54vvPP+cGLC44Po7T0nfziwYPDGHkzbR4gurEOeaUGaJ4zYjQkU5U50QtBOUJN3RxQVbVWrVgPCCuL03QAUYIh8KRUBgP+OMnFo0KjX9meZPEnkeft2348tXrlrqpqRhWlpawsrwEazQKoWM9HZbtFVpbt8vn823r9vez8IpFXLxwHlYQJkusHfZlb++6Ibfy6OEDzMbj8LwiPmxt4/PuLra2PxpPRKMR226SShMfLH0gYmfn58yz53nsBc++sdYLMgkd9MlhLndiUCRq3Y7ngRNGkBOujs3N94hEoyYEuYoBy8Hcb+ZBGD1ymPvbUJ6fm8Pq9WsIioTAKnFo5v7dO3j+7ClisZgpy8gDjV7gpSgGuOgBcf8Ui9++ddOUv3z9hl/ZLAJBfDgRcRrVB7MzcczwchRkGQYzgPYUSv4O+uTqlcvmXzajgF5IV7diOYh6Wg39wMdyTMm5zHlbCqOGKCXa5jRU5L/BiFETY+vmX34Sp6ddyV4xIkRrMV5Oy2oZkaTO1OOSDIgrWjXd6oOJB+lLQzbCVZHxZP0doSEtN6EIhVeHZISruO+q66u0v5j84PRcD/hiwiNvFhdUu6/FE4pT50FMTOlD0vB24uX3XTDeAKfs2lxObTF7C0XGNjoJWxtQM6RyPfc5jWJjJItyUH89l3nDezvB31FFvLW9nv8HGOsGkWhTsAkAAAAASUVORK5CYII=", 'base64'
  )

function GET() {
  return new server.NextResponse(buffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': "public, max-age=0, must-revalidate",
    },
  })
}

const dynamic = 'force-static'

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Ffavicon.ico%2Froute&name=app%2Ffavicon.ico%2Froute&pagePath=private-next-app-dir%2Ffavicon.ico&appDir=C%3A%5CUsers%5CJohn%5CDocuments%5CGitHub%5Cpersonal-website%5Capp&appPaths=%2Ffavicon.ico&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/favicon.ico/route","pathname":"/favicon.ico","filename":"favicon","bundlePath":"app/favicon.ico/route"},"resolvedPagePath":"next-metadata-route-loader?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!C:\\Users\\John\\Documents\\GitHub\\personal-website\\app\\favicon.ico?__next_metadata__","nextConfigOutput":""}
    const routeModule = new (module_default())({
      ...options,
      userland: favicon_next_metadata_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/favicon.ico/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [763,572], () => (__webpack_exec__(7856)));
module.exports = __webpack_exports__;

})();